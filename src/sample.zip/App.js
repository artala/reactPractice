import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import Sample from './sample/Sample';
//import Sample from './sample/Sample';

class App extends Component {

    state={
      sample : [
        {name:'Arun kumar', age:'23'},
        {name:'Rohith', age:'23'},
        {name:'Hari',age:'24'}
      ],
      person: 'someother',
      clickStatus : false
    }


    nameHandler=(newName)=>{
      //console.log('you clicked me');
      //this.state.sample[0].name='Arun';
      this.setState({
        sample : [
          {name:newName, age:'23'},
          {name:'Rohith', age:'23'},
          {name:'Hari',age:'25'}
        ]
      }
        
      )
    }

    nameChangeHandler=(event)=>{
      this.setState({
        sample : [
          {name:'Arun', age:'23'},
          {name:event.target.value, age:'23'},
          {name:'Hari',age:'25'}
        ]
      }
        
      )
    }

    clickNameHandler = ()=>{
      const doesSample = this.state.clickStatus;
      console.log(doesSample)
      console.log(!doesSample)
      this.setState({clickStatus:!doesSample});
      console.log({clickStatus:!doesSample})
    }

  render() {
    const style ={
      backgroundColor:'white',
      font:'inherit',
      border : '1px solid blue',
      padding : '8px',
      cursor : 'pointer'
    }

    let samples = null;
    if(this.state.clickStatus){
      samples = (
        <div>
        <Sample 
        name={this.state.sample[0].name} 
        age={this.state.sample[0].age}/>
        <Sample 
        name ={this.state.sample[1].name} 
        age={this.state.sample[1].age}
        click={this.nameHandler.bind(this,'Mandar')}
        changed={this.nameChangeHandler}
        >my hobbies are football</Sample>
        <Sample 
        name ={this.state.sample[2].name} 
        age={this.state.sample[2].age}/>
      </div>
      );
    }
    return (
      // React.createElement('div',{className:'App'},React.createElement('h1',null,'Hai'))
              
      <div className="App">
        <h1>Hello World</h1>
        <p>Hai This is arun</p>
        {/* <button style={style} onClick={this.nameHandler.bind(this,'Arun')}>CLick me</button> */}
        <button style={style} onClick={this.clickNameHandler}>CLick me!...</button>
        {samples}
        {/* {this.state.clickStatus===true ? */}
          {/* <div>
            <Sample 
            name={this.state.sample[0].name} 
            age={this.state.sample[0].age}/>
            <Sample 
            name ={this.state.sample[1].name} 
            age={this.state.sample[1].age}
            click={this.nameHandler.bind(this,'Mandar')}
            changed={this.nameChangeHandler}
            >my hobbies are football</Sample>
            <Sample 
            name ={this.state.sample[2].name} 
            age={this.state.sample[2].age}/>
          </div>  */}
          {/* : null */}
        {/* } */}
      </div>
      
    );
  }
}

export default App;
